from django.contrib import admin
# from .models import Company_Master,OTP

# admin.site.register(Company_Master)
# admin.site.register(OTP)